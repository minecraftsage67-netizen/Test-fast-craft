package com.fast.fastcraft;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences prefs = getSharedPreferences("main", MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(48, 96, 48, 48);

        TextView title = new TextView(this);
        title.setText("FASTCRAFT");
        title.setTextSize(36);
        title.setTextColor(0xFF00FFC8);
        title.setGravity(Gravity.CENTER);
        EditText address = new EditText(this);
        address.setSingleLine(true);
        address.setHint("server ip:19132");
        address.setText(prefs.getString("address", ""));
        Button join = new Button(this);
        join.setText("Test server");
        Button controls = new Button(this);
        controls.setText("Custom buttons");
        TextView log = new TextView(this);
        log.setTextIsSelectable(true);

        join.setOnClickListener(v -> {
            String target = address.getText().toString().trim();
            if (target.isEmpty()) {
                log.setText("Enter a server address first.");
                return;
            }
            prefs.edit().putString("address", target).apply();
            join.setEnabled(false);
            log.setText("Connecting...");
            new Thread(() -> {
                String result = runCore(target);
                runOnUiThread(() -> {
                    log.setText(result);
                    join.setEnabled(true);
                });
            }).start();
        });
        controls.setOnClickListener(v -> startActivity(new Intent(this, ControlsActivity.class)));

        box.addView(title, -1, -2);
        box.addView(address, -1, -2);
        box.addView(join, -1, -2);
        box.addView(controls, -1, -2);
        box.addView(log, -1, -2);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);
    }

    /** Runs the Rust program packaged as a native library file. */
    private String runCore(String target) {
        try {
            String path = new File(getApplicationInfo().nativeLibraryDir, "libfastcraft.so").getPath();
            Process p = new ProcessBuilder(path, target).redirectErrorStream(true).start();
            InputStream in = p.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
            p.waitFor();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
