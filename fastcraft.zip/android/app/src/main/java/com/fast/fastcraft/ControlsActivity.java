package com.fast.fastcraft;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Layout editor: drag to move, tap to resize or delete, add new buttons. */
public class ControlsActivity extends Activity {
    private FrameLayout screen;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("controls", MODE_PRIVATE);
        screen = new FrameLayout(this);
        setContentView(screen);

        Button add = new Button(this);
        add.setText("+ Add button");
        add.setOnClickListener(v -> {
            EditText name = new EditText(this);
            name.setHint("label");
            new AlertDialog.Builder(this).setTitle("New button").setView(name)
                .setPositiveButton("Add", (d, w) -> {
                    String label = name.getText().toString().trim();
                    if (!label.isEmpty()) {
                        place(label, 300, 300, 160);
                        save();
                    }
                }).show();
        });
        screen.addView(add, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        load();
    }

    private void load() {
        String def = "[{\"t\":\"W\",\"x\":220,\"y\":500,\"s\":160},{\"t\":\"A\",\"x\":50,\"y\":670,\"s\":160},"
                + "{\"t\":\"S\",\"x\":220,\"y\":670,\"s\":160},{\"t\":\"D\",\"x\":390,\"y\":670,\"s\":160},"
                + "{\"t\":\"JUMP\",\"x\":1600,\"y\":670,\"s\":180}]";
        try {
            JSONArray list = new JSONArray(prefs.getString("layout", def));
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.getJSONObject(i);
                place(o.getString("t"), o.getInt("x"), o.getInt("y"), o.getInt("s"));
            }
        } catch (Exception e) {
            prefs.edit().remove("layout").apply();
        }
    }

    private void place(String label, int x, int y, int size) {
        TextView key = new TextView(this);
        key.setText(label);
        key.setGravity(Gravity.CENTER);
        key.setTextColor(0xFF00FFC8);
        key.setTag("key");
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x991B1F3B);
        bg.setStroke(4, 0xFF00FFC8);
        bg.setCornerRadius(32);
        key.setBackground(bg);
        key.setX(x);
        key.setY(y);
        float[] start = new float[4];
        key.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                start[0] = e.getRawX();
                start[1] = e.getRawY();
                start[2] = v.getX();
                start[3] = v.getY();
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                float nx = start[2] + e.getRawX() - start[0];
                float ny = start[3] + e.getRawY() - start[1];
                v.setX(Math.max(0, Math.min(nx, screen.getWidth() - v.getWidth())));
                v.setY(Math.max(0, Math.min(ny, screen.getHeight() - v.getHeight())));
            } else if (e.getAction() == MotionEvent.ACTION_UP) {
                if (Math.hypot(e.getRawX() - start[0], e.getRawY() - start[1]) < 16) menu(key);
                save();
            }
            return true;
        });
        screen.addView(key, new FrameLayout.LayoutParams(size, size));
    }

    private void menu(TextView key) {
        String[] items = {"Bigger", "Smaller", "Delete"};
        new AlertDialog.Builder(this).setTitle(key.getText()).setItems(items, (d, i) -> {
            if (i == 2) {
                screen.removeView(key);
            } else {
                FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) key.getLayoutParams();
                p.width = p.height = Math.max(80, Math.min(400, p.width + (i == 0 ? 20 : -20)));
                key.setLayoutParams(p);
            }
            save();
        }).show();
    }

    private void save() {
        JSONArray list = new JSONArray();
        try {
            for (int i = 0; i < screen.getChildCount(); i++) {
                if (!"key".equals(screen.getChildAt(i).getTag())) continue;
                TextView key = (TextView) screen.getChildAt(i);
                list.put(new JSONObject().put("t", key.getText().toString())
                        .put("x", (int) key.getX()).put("y", (int) key.getY())
                        .put("s", key.getLayoutParams().width));
            }
        } catch (Exception e) {
            return;
        }
        prefs.edit().putString("layout", list.toString()).apply();
    }
}
