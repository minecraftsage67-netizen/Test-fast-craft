//! Minimal RakNet client for MCPE 0.15.x: server ping and connection handshake.
use std::io::{Error, ErrorKind, Result};
use std::net::{SocketAddr, SocketAddrV4, ToSocketAddrs, UdpSocket};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

pub const MAGIC: [u8; 16] = [
    0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe, 0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78,
];
/// RakNet versions to try, newest first.
const RAKNET_VERSIONS: [u8; 3] = [8, 7, 6];
const MTU: u16 = 1400;

#[derive(Debug, PartialEq)]
pub struct ServerInfo {
    pub name: String,
    pub protocol: u32,
    pub version: String,
    pub online: u32,
    pub max: u32,
}

pub struct Connection {
    pub socket: UdpSocket,
    pub mtu: u16,
    pub raknet_version: u8,
}

fn bad(msg: &str) -> Error {
    Error::new(ErrorKind::InvalidData, msg.to_string())
}

fn guid() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_nanos() as u64).unwrap_or(1)
}

fn open(addr: &str) -> Result<(UdpSocket, SocketAddrV4)> {
    let target = addr
        .to_socket_addrs()?
        .find_map(|a| match a {
            SocketAddr::V4(v4) => Some(v4),
            _ => None,
        })
        .ok_or_else(|| bad("no IPv4 address"))?;
    let socket = UdpSocket::bind("0.0.0.0:0")?;
    socket.connect(target)?;
    socket.set_read_timeout(Some(Duration::from_secs(2)))?;
    Ok((socket, target))
}

/// Send up to 3 times until a reply with one of the wanted IDs arrives.
fn request(socket: &UdpSocket, packet: &[u8], wanted: &[u8]) -> Result<Vec<u8>> {
    let mut buf = [0u8; 2048];
    for _ in 0..3 {
        socket.send(packet)?;
        for _ in 0..8 {
            match socket.recv(&mut buf) {
                Ok(n) if n > 0 && wanted.contains(&buf[0]) => return Ok(buf[..n].to_vec()),
                Ok(_) => continue,
                Err(e) if matches!(e.kind(), ErrorKind::WouldBlock | ErrorKind::TimedOut) => break,
                Err(e) => return Err(e),
            }
        }
    }
    Err(Error::new(ErrorKind::TimedOut, "server did not reply"))
}

pub fn parse_pong(data: &[u8]) -> Result<ServerInfo> {
    // id(1) time(8) guid(8) magic(16) length(2) text
    if data.len() < 35 || data[0] != 0x1c || data[17..33] != MAGIC {
        return Err(bad("invalid pong"));
    }
    let len = u16::from_be_bytes([data[33], data[34]]) as usize;
    let raw = data.get(35..35 + len).ok_or_else(|| bad("short pong"))?;
    let text = String::from_utf8_lossy(raw);
    let p: Vec<&str> = text.split(';').collect();
    if p.len() < 3 || p[0] != "MCPE" {
        return Err(bad("not an MCPE server"));
    }
    let num = |i: usize| p.get(i).and_then(|s| s.parse().ok()).unwrap_or(0);
    Ok(ServerInfo {
        name: p[1].to_string(),
        protocol: num(2),
        version: p.get(3).unwrap_or(&"").to_string(),
        online: num(4),
        max: num(5),
    })
}

pub fn ping(addr: &str) -> Result<ServerInfo> {
    let (socket, _) = open(addr)?;
    let mut p = vec![0x01];
    p.extend_from_slice(&1u64.to_be_bytes());
    p.extend_from_slice(&MAGIC);
    p.extend_from_slice(&guid().to_be_bytes());
    parse_pong(&request(&socket, &p, &[0x1c])?)
}

pub fn connect(addr: &str) -> Result<Connection> {
    let (socket, target) = open(addr)?;
    for version in RAKNET_VERSIONS {
        // Open Connection Request 1, padded so UDP + IP headers total the MTU.
        let mut p = vec![0x05];
        p.extend_from_slice(&MAGIC);
        p.push(version);
        p.resize(MTU as usize - 28, 0);
        let r = request(&socket, &p, &[0x06, 0x19])?;
        if r[0] == 0x19 {
            continue; // incompatible version, try the next
        }
        // id(1) magic(16) guid(8) security(1) mtu(2)
        if r.len() < 28 || r[1..17] != MAGIC {
            return Err(bad("invalid reply 1"));
        }
        if r[25] != 0 {
            return Err(bad("server requires RakNet security"));
        }
        let mtu = u16::from_be_bytes([r[26], r[27]]).min(MTU);

        // Open Connection Request 2
        let mut p = vec![0x07];
        p.extend_from_slice(&MAGIC);
        p.push(4); // IPv4, address bytes are inverted
        p.extend(target.ip().octets().iter().map(|b| !b));
        p.extend_from_slice(&target.port().to_be_bytes());
        p.extend_from_slice(&mtu.to_be_bytes());
        p.extend_from_slice(&guid().to_be_bytes());
        let r = request(&socket, &p, &[0x08])?;
        if r.len() < 25 || r[1..17] != MAGIC {
            return Err(bad("invalid reply 2"));
        }
        return Ok(Connection { socket, mtu, raknet_version: version });
    }
    Err(bad("no compatible RakNet version"))
}
