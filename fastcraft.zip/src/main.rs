fn main() {
    let Some(addr) = std::env::args().nth(1) else {
        eprintln!("usage: fastcraft <ip:port>");
        std::process::exit(2);
    };
    let result = fastcraft::ping(&addr).and_then(|s| {
        println!("{} | {} (protocol {}) | {}/{}", s.name, s.version, s.protocol, s.online, s.max);
        fastcraft::connect(&addr)
    });
    match result {
        Ok(c) => println!("Handshake OK: RakNet {}, MTU {}", c.raknet_version, c.mtu),
        Err(e) => {
            eprintln!("Failed: {e}");
            std::process::exit(1);
        }
    }
}
