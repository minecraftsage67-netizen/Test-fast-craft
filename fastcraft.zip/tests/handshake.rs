use fastcraft::{connect, ping, MAGIC};
use std::net::UdpSocket;
use std::thread;

/// Fake server that only accepts RakNet 7, to exercise the version fallback.
fn fake_server() -> String {
    let s = UdpSocket::bind("127.0.0.1:0").unwrap();
    let addr = s.local_addr().unwrap().to_string();
    thread::spawn(move || {
        let mut b = [0u8; 2048];
        loop {
            let (n, from) = s.recv_from(&mut b).unwrap();
            let mut r = Vec::new();
            match b[0] {
                0x01 => {
                    let text = b"MCPE;Test;84;0.15.10;1;20";
                    r.push(0x1c);
                    r.extend_from_slice(&[0; 16]);
                    r.extend_from_slice(&MAGIC);
                    r.extend_from_slice(&(text.len() as u16).to_be_bytes());
                    r.extend_from_slice(text);
                }
                0x05 => {
                    assert_eq!(n, 1372);
                    r.push(if b[17] == 7 { 0x06 } else { 0x19 });
                    r.extend_from_slice(&MAGIC);
                    r.extend_from_slice(&[0; 9]);
                    r.extend_from_slice(&1400u16.to_be_bytes());
                }
                0x07 => {
                    assert_eq!(n, 34);
                    r.push(0x08);
                    r.extend_from_slice(&MAGIC);
                    r.extend_from_slice(&[0; 18]);
                }
                _ => continue,
            }
            s.send_to(&r, from).unwrap();
        }
    });
    addr
}

#[test]
fn pings_and_connects() {
    let addr = fake_server();
    let info = ping(&addr).unwrap();
    assert_eq!((info.name.as_str(), info.protocol, info.max), ("Test", 84, 20));
    let c = connect(&addr).unwrap();
    assert_eq!((c.raknet_version, c.mtu), (7, 1400));
}
